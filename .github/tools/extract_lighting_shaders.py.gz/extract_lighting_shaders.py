#!/usr/bin/env python3
"""Extract Source SDK 2012 lighting/shader files and generate per-file docs.

Designed to run in GitHub Actions. It pins the upstream repository to an exact
commit, reads every C/C++ header/implementation candidate in full, applies a
conservative path/content classifier, copies selected source and shader files,
and writes one Markdown analysis for each selected .h/.cpp file.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import textwrap
import zipfile
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path, PurePosixPath
from typing import Iterable

UPSTREAM = "https://github.com/nn-firc/source-sdk-2012.git"
PINNED_COMMIT = "c4bd4e14f37678628f2b5fe98324d07d3f117a29"

# Everything in these trees is part of shader implementation, shader API, or
# offline/running lighting. The first tree also contains source shaders and
# generated shader include blobs; all regular files are retained as requested.
WHOLE_TREE_PREFIXES = (
    "materialsystem/stdshaders/",
)
CPP_TREE_PREFIXES = (
    "materialsystem/shaderapidx9/",
    "materialsystem/shaderapiempty/",
    "public/shaderapi/",
    "utils/vrad/",
    "utils/vrad_dll/",
    "utils/radiosity/",
)

# Strong path terms: a .h/.cpp whose path contains one is in scope unless it is
# an obvious third-party/system header.
STRONG_PATH_TERMS = (
    "shader", "lighting", "lightmap", "lightcache", "worldlight", "studiolight",
    "radiosity", "vrad", "shadowmgr", "shadow_manager", "clientshadow",
    "cubemap", "irradiance", "ambientcube", "ambient_cube", "phong",
    "flashlight", "projectedtexture", "projected_texture", "env_projected",
)

# Content terms are weighted. Generic words such as "render" are deliberately
# not enough by themselves.
TERM_WEIGHTS = {
    "shader": 5, "vertex shader": 5, "pixel shader": 5, "compute shader": 5,
    "ishaderapi": 7, "ishadershadow": 7, "cbasesshader": 7, "cbasesshader": 7,
    "lightmap": 7, "light cache": 7, "lightcache": 7, "worldlight": 7,
    "lightdesc_t": 7, "lightdesc": 6, "radiosity": 7, "irradiance": 6,
    "ambient cube": 6, "ambientcube": 6, "spherical harmonics": 6,
    "phong": 6, "specular": 3, "diffuse": 2, "fresnel": 3,
    "normal map": 3, "bump map": 3, "bumpmap": 3, "envmap": 4,
    "cubemap": 5, "flashlight": 5, "projected texture": 5,
    "shadow depth": 5, "shadow map": 5, "shadowmgr": 6,
    "dynamic light": 5, "static light": 5, "direct lighting": 5,
    "indirect lighting": 5, "light probe": 5, "lightstyle": 4,
    "lighting state": 4, "lighting origin": 4, "illumination": 3,
    "hdr": 2, "bloom": 2, "tone mapping": 2, "materialvar": 2,
    "shaderapi": 6, "shader shadow": 6, "shader constant": 4,
    "vertexlit": 5, "lightmapped": 5, "lightmappedgeneric": 6,
}

RENDER_CONTEXT_TERMS = (
    "materialsystem", "shaderapi", "ishader", "imaterial", "rendercontext",
    "draw", "mesh", "gpu", "vertex", "pixel", "texture", "sampler",
    "light", "shadow", "surface", "model", "world", "bsp",
)

EXCLUDED_PATH_PARTS = {
    ".git", "thirdparty", "third_party", "external", "lib", "common/gl",
}

SHADER_EXTENSIONS = {
    ".fxc", ".vsh", ".psh", ".hlsl", ".glsl", ".fxh", ".shader", ".vcs",
    ".inc", ".inc2", ".vsi", ".psi", ".cg", ".cginc",
}
CPP_EXTENSIONS = {".h", ".hpp", ".hh", ".hxx", ".cpp", ".cc", ".cxx"}
DOC_EXTENSIONS = {".h", ".cpp"}  # exact user-requested documentation set

@dataclass
class Selection:
    path: str
    kind: str
    reasons: list[str]
    score: int
    sha256: str
    size_bytes: int
    line_count: int


def run(cmd: list[str], cwd: Path | None = None) -> str:
    proc = subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT, check=False)
    if proc.returncode:
        raise RuntimeError(f"Command failed ({proc.returncode}): {' '.join(cmd)}\n{proc.stdout}")
    return proc.stdout


def clone_pinned(dest: Path) -> None:
    run(["git", "clone", "--filter=blob:none", "--no-checkout", UPSTREAM, str(dest)])
    run(["git", "checkout", "--detach", PINNED_COMMIT], cwd=dest)
    actual = run(["git", "rev-parse", "HEAD"], cwd=dest).strip()
    if actual != PINNED_COMMIT:
        raise RuntimeError(f"Commit mismatch: expected {PINNED_COMMIT}, got {actual}")


def read_text_lossless(path: Path) -> tuple[str, bytes]:
    raw = path.read_bytes()
    # Source SDK contains mixed encodings. Preserve original bytes in files/,
    # but decode for analysis without dropping data.
    for enc in ("utf-8", "utf-8-sig", "cp1252", "latin-1"):
        try:
            return raw.decode(enc), raw
        except UnicodeDecodeError:
            pass
    return raw.decode("utf-8", errors="replace"), raw


def normalized(rel: Path) -> str:
    return rel.as_posix()


def has_excluded_part(rel_s: str) -> bool:
    low = rel_s.lower()
    parts = set(PurePosixPath(low).parts)
    return any(part in parts or token in low for token in EXCLUDED_PATH_PARTS)


def content_score(text: str) -> tuple[int, list[str]]:
    low = text.lower()
    hits: list[str] = []
    score = 0
    for term, weight in TERM_WEIGHTS.items():
        if term in low:
            score += weight
            hits.append(term)
    # Repeated high-value API usage is stronger than a single mention in a comment.
    for term in ("ishaderapi", "ishadershadow", "lightdesc_t", "lightmap", "shaderapi"):
        count = low.count(term)
        if count > 2:
            score += min(8, count // 2)
    return score, hits


def classify(rel: Path, text: str, raw: bytes) -> Selection | None:
    rel_s = normalized(rel)
    low_path = rel_s.lower()
    suffix = rel.suffix.lower()
    reasons: list[str] = []
    kind = ""

    if any(low_path.startswith(p) for p in WHOLE_TREE_PREFIXES):
        kind = "standard shader tree"
        reasons.append("inside materialsystem/stdshaders, the engine's standard shader source/build tree")
    elif suffix in CPP_EXTENSIONS and any(low_path.startswith(p) for p in CPP_TREE_PREFIXES):
        kind = "shader/lighting subsystem C++"
        reasons.append("inside an explicit shader API or lighting tool implementation tree")
    elif suffix in CPP_EXTENSIONS:
        if has_excluded_part(rel_s):
            return None
        path_hits = [t for t in STRONG_PATH_TERMS if t in low_path]
        score, term_hits = content_score(text)
        context_hits = [t for t in RENDER_CONTEXT_TERMS if t in text.lower()]
        if path_hits:
            kind = "lighting/shader C++"
            reasons.append("path/name contains strong lighting or shader term(s): " + ", ".join(path_hits[:8]))
        elif score >= 18 and len(context_hits) >= 3:
            kind = "lighting/shader helper C++"
            reasons.append(f"full-file semantic score {score} with rendering integration terms")
            reasons.append("content indicators: " + ", ".join(term_hits[:12]))
        else:
            return None
    elif suffix in SHADER_EXTENSIONS and "shader" in low_path:
        kind = "shader source/include"
        reasons.append("shader-language source or include file in a shader path")
    else:
        return None

    score, hits = content_score(text)
    if hits and not any("content indicators" in r for r in reasons):
        reasons.append("content indicators: " + ", ".join(hits[:12]))
    digest = hashlib.sha256(raw).hexdigest()
    return Selection(
        path=rel_s,
        kind=kind,
        reasons=reasons,
        score=score,
        sha256=digest,
        size_bytes=len(raw),
        line_count=text.count("\n") + (1 if text else 0),
    )


def clean_comment(s: str) -> str:
    s = re.sub(r"^\s*(//+|/\*+|\*+|#+)\s?", "", s)
    s = re.sub(r"\s*\*/\s*$", "", s)
    return s.strip()


def extract_summary(text: str) -> str:
    lines = text.splitlines()[:160]
    collected: list[str] = []
    in_block = False
    for line in lines:
        st = line.strip()
        if not st:
            if collected:
                break
            continue
        if st.startswith("/*"):
            in_block = True
        if in_block or st.startswith("//"):
            c = clean_comment(st)
            if c and not re.fullmatch(r"[=\-_*]{4,}", c) and "copyright" not in c.lower():
                collected.append(c)
        elif collected:
            break
        if "*/" in st:
            in_block = False
    joined = " ".join(collected)
    joined = re.sub(r"\s+", " ", joined).strip()
    return joined[:700]


def unique(items: Iterable[str], limit: int = 30) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for item in items:
        item = item.strip()
        if item and item not in seen:
            seen.add(item)
            out.append(item)
            if len(out) >= limit:
                break
    return out


def extract_symbols(text: str) -> dict[str, list[str]]:
    includes = unique(re.findall(r'^\s*#\s*include\s*[<"]([^>"]+)[>"]', text, re.M), 40)
    classes = unique(re.findall(r'\b(?:class|struct)\s+([A-Za-z_]\w*)', text), 30)
    enums = unique(re.findall(r'\benum(?:\s+class)?\s+([A-Za-z_]\w*)', text), 20)
    macros = unique(re.findall(r'^\s*#\s*define\s+([A-Za-z_]\w*)', text, re.M), 30)
    # Function-like declarations/definitions. Filter language keywords/macros.
    function_candidates = re.findall(
        r'(?m)^\s*(?:[\w:<>,~*&\[\]\s]+\s+)?([A-Za-z_]\w*(?:::\w+)*)\s*\([^;{}]{0,300}\)\s*(?:const\s*)?(?:\{|;)',
        text,
    )
    deny = {"if", "for", "while", "switch", "return", "sizeof", "assert", "static_assert", "catch"}
    functions = unique((f for f in function_candidates if f.split("::")[-1] not in deny), 50)
    globals_ = unique(re.findall(r'(?m)^\s*(?:static\s+)?(?:const\s+)?(?:bool|int|float|double|Vector\w*|matrix3x4_t|ConVar)\s+([A-Za-z_]\w*)\s*(?:=|;)', text), 25)
    return {"includes": includes, "classes": classes, "enums": enums,
            "macros": macros, "functions": functions, "globals": globals_}


def bullet(items: list[str], empty: str = "None detected by the static scan.") -> str:
    if not items:
        return f"- {empty}"
    return "\n".join(f"- `{x}`" for x in items)


def infer_purpose(rel_s: str, summary: str, sel: Selection, symbols: dict[str, list[str]]) -> str:
    name = Path(rel_s).name
    stem = Path(rel_s).stem.replace("_", " ")
    low = rel_s.lower()
    if summary:
        return summary
    if "lightmap" in low:
        return f"Implements or declares {stem} behavior for Source lightmap storage, upload, sampling, or rendering integration."
    if "lightcache" in low:
        return "Implements the runtime lighting cache used to gather and reuse local illumination information for renderable objects."
    if "studiolight" in low:
        return "Implements studio-model lighting setup and evaluation, bridging engine light data to model rendering."
    if "shadow" in low:
        return f"Implements or declares {stem} behavior for shadow generation, projection, management, or shader integration."
    if "shaderapi" in low:
        return "Implements or declares the renderer-facing shader API used to configure GPU state, shader constants, textures, and draw behavior."
    if "stdshaders" in low:
        return f"Implements or supports the Source standard shader `{name}`, including material parameters, shader permutations, and draw-state setup."
    if "vrad" in low or "radiosity" in low:
        return "Implements offline map-lighting/radiosity work used to bake direct and indirect illumination into Source map data."
    top = symbols["classes"][:1] or symbols["functions"][:1]
    subject = f" around `{top[0]}`" if top else ""
    return f"Provides lighting or shader support{subject}; inclusion is based on full-file path/content analysis."


def concept_hits(text: str) -> list[str]:
    low = text.lower()
    concepts = {
        "lightmaps": ("lightmap", "luxel"),
        "dynamic lights": ("dynamic light", "dlight", "lightdesc"),
        "static/world lights": ("worldlight", "static light"),
        "ambient cubes / probes": ("ambient cube", "ambientcube", "light probe"),
        "shadows": ("shadow",),
        "normal/bump mapping": ("normal map", "normalmap", "bumpmap", "bump map"),
        "Phong/specular lighting": ("phong", "specular"),
        "diffuse lighting": ("diffuse",),
        "Fresnel response": ("fresnel",),
        "environment maps/cubemaps": ("envmap", "cubemap"),
        "HDR/tone mapping": ("hdr", "tone map", "tonemap"),
        "radiosity/indirect lighting": ("radiosity", "indirect lighting"),
        "projected/flashlight lighting": ("flashlight", "projected texture", "projectedtexture"),
        "shader permutations/combos": ("static combo", "dynamic combo", "shader combo"),
        "GPU shader constants": ("shader constant", "setvertexshaderconstant", "setpixelshaderconstant"),
        "material parameters": ("imaterialvar", "shader_param", "material var"),
    }
    return [label for label, terms in concepts.items() if any(t in low for t in terms)]


def integration_notes(rel_s: str, text: str, syms: dict[str, list[str]]) -> list[str]:
    low = text.lower()
    notes: list[str] = []
    if "ishaderapi" in low:
        notes.append("Uses `IShaderDynamicAPI`/`IShaderAPI`-style calls to push dynamic GPU state and constants.")
    if "ishadershadow" in low:
        notes.append("Defines snapshot/static render state through `IShaderShadow`.")
    if "cbaseshader" in low or "cbasesshader" in low:
        notes.append("Participates in the standard-shader framework and its material parameter lifecycle.")
    if "imaterialvar" in low:
        notes.append("Reads material variables that originate in VMT/material definitions.")
    if "lightdesc_t" in low:
        notes.append("Consumes or produces `LightDesc_t` descriptors shared by engine/material/studio rendering.")
    if "bsp" in low or "worldlight" in low:
        notes.append("Integrates with BSP/world-light data or map lighting lumps.")
    if "studio" in rel_s.lower() or "studio" in low:
        notes.append("Integrates with studio-model rendering and model lighting state.")
    if not notes:
        incs = syms["includes"][:4]
        if incs:
            notes.append("Primary integration clues come from includes: " + ", ".join(f"`{x}`" for x in incs) + ".")
    return notes


def performance_notes(text: str) -> list[str]:
    low = text.lower()
    notes: list[str] = []
    loops = len(re.findall(r'\b(?:for|while)\s*\(', text))
    if loops:
        notes.append(f"Contains {loops} explicit loop(s); review iteration bounds when changing hot rendering or baking paths.")
    if any(x in low for x in ("setpixelshaderconstant", "setvertexshaderconstant", "bindtexture", "bind(")):
        notes.append("Issues GPU state/constant/texture updates; redundant changes can increase draw-call overhead.")
    if any(x in low for x in ("new ", "malloc(", "alloc", "realloc")):
        notes.append("Contains allocation-related code; avoid adding per-frame/per-draw heap churn.")
    if any(x in low for x in ("ray", "trace", "radiosity", "sample")) and loops:
        notes.append("Sampling/tracing work may scale with geometry, lights, texels, or rays and can be computationally expensive.")
    if "cache" in low:
        notes.append("Caching behavior is performance-sensitive; invalidation and key correctness matter as much as hit rate.")
    return unique(notes, 10) or ["No obvious hot-loop or GPU-state warning was detected; call frequency still determines cost."]


def state_notes(text: str) -> list[str]:
    low = text.lower()
    notes: list[str] = []
    if re.search(r'(?m)^\s*static\s+(?!const)', text):
        notes.append("Contains mutable static state; check lifetime, reset behavior, and thread access before modification.")
    if any(x in low for x in ("mutex", "thread", "interlocked", "atomic")):
        notes.append("Contains explicit concurrency primitives or thread-related behavior.")
    if any(x in low for x in ("begin", "end", "pushrender", "poprender", "pushmatrix", "popmatrix")):
        notes.append("May rely on balanced begin/end or push/pop render-state operations.")
    if "cache" in low:
        notes.append("Maintains cached state whose lifetime may span frames, maps, materials, or render contexts.")
    return unique(notes, 10) or ["No explicit threading primitive was detected; most renderer code should still be treated as context/state sensitive."]


def platform_notes(text: str) -> list[str]:
    guards = unique(re.findall(r'(?m)^\s*#\s*(?:if|ifdef|ifndef|elif)\s+(.+)$', text), 40)
    interesting = [g for g in guards if any(k in g.upper() for k in (
        "WIN", "LINUX", "OSX", "DX", "X360", "PS3", "TOGL", "OPENGL", "SHADER", "HDR", "FAST", "DEBUG"
    ))]
    return interesting[:20]


def notices(text: str) -> list[str]:
    out: list[str] = []
    for line_no, line in enumerate(text.splitlines(), 1):
        if re.search(r'\b(TODO|FIXME|HACK|WARNING|NOTE)\b', line, re.I):
            cleaned = clean_comment(line)[:240]
            if cleaned:
                out.append(f"Line {line_no}: {cleaned}")
        if len(out) >= 20:
            break
    return out


def make_doc(repo_root: Path, sel: Selection, out_path: Path) -> None:
    src = repo_root / sel.path
    text, _ = read_text_lossless(src)
    syms = extract_symbols(text)
    summary = extract_summary(text)
    purpose = infer_purpose(sel.path, summary, sel, syms)
    concepts = concept_hits(text)
    integration = integration_notes(sel.path, text, syms)
    perf = performance_notes(text)
    state = state_notes(text)
    platforms = platform_notes(text)
    flags = notices(text)

    function_excerpt = syms["functions"][:25]
    related = unique(
        [i for i in syms["includes"] if any(k in i.lower() for k in ("shader", "light", "material", "render", "shadow", "studio"))],
        20,
    )
    risk_notes = [
        "Changing material parameter indices, shader constant registers, combo definitions, or vertex formats can silently desynchronize C++ and shader code.",
        "Preserve static-versus-dynamic shader state separation; snapshot state is not interchangeable with per-draw state.",
        "Validate all supported render backends and feature levels represented by conditional compilation.",
    ]
    if "lightmap" in text.lower():
        risk_notes.append("Lightmap format, page allocation, coordinate, and gamma/HDR assumptions must remain consistent with BSP/tool output.")
    if "shadow" in text.lower():
        risk_notes.append("Shadow changes can affect depth bias, filtering, atlas allocation, projection matrices, and pass ordering.")
    if "vrad" in sel.path.lower() or "radiosity" in text.lower():
        risk_notes.append("Baked-lighting changes alter map output determinism, compile time, and compatibility with runtime readers.")

    md = f"""# `{sel.path}`

## File identity

- **Repository:** `nn-firc/source-sdk-2012`
- **Pinned commit:** `{PINNED_COMMIT}`
- **Classification:** {sel.kind}
- **Lines read:** {sel.line_count:,}
- **Bytes:** {sel.size_bytes:,}
- **SHA-256:** `{sel.sha256}`
- **Why it is in scope:** {'; '.join(sel.reasons)}

> This document was generated after reading the complete file. It combines extracted symbols/comments with conservative static-analysis inferences. Confirm behavior against call sites and runtime/tool tests before making production changes.

## 1. What is this file's purpose?

{purpose}

## 2. What does it do?

It defines or supports the lighting/shader responsibilities indicated by its symbols and integration points. The most relevant detected concepts are: {', '.join(concepts) if concepts else 'general shader or lighting infrastructure'}. Its concrete API surface is summarized below rather than guessed from the filename alone.

## 3. Where does it sit in the pipeline?

{chr(10).join('- ' + x for x in integration)}

## 4. What are its important declarations or types?

### Classes and structs
{bullet(syms['classes'])}

### Enums
{bullet(syms['enums'])}

### Macros
{bullet(syms['macros'])}

## 5. What functions or entry points matter most?

{bullet(function_excerpt)}

## 6. What inputs does it consume?

- Compile-time inputs include the headers, feature macros, platform guards, and shader permutations listed in this file.
- Runtime/tool inputs are represented by function parameters, material variables, render/shader interfaces, map/model data, textures, constants, and light descriptors found in the declarations above.
- Do not assume default values are harmless: many Source shader helpers use sentinel parameter indices and feature flags that are initialized elsewhere.

## 7. What outputs or side effects can it produce?

- It may configure render state, bind resources, upload shader constants, produce lighting samples/lightmaps, mutate caches, or emit draw/tool output depending on the entry point.
- Side effects are especially likely where the file uses shader APIs, material variables, global/static caches, BSP data, or render-context begin/end operations.
- Return values alone may not describe behavior; inspect state changes at each call site.

## 8. What does it depend on?

{bullet(syms['includes'])}

## 9. What lighting or shader concepts appear here?

{bullet(concepts, 'No named lighting model was detected; this file is included through structural shader/lighting scope.')}

## 10. What are the performance-sensitive areas?

{chr(10).join('- ' + x for x in perf)}

## 11. What state, lifetime, or threading concerns exist?

{chr(10).join('- ' + x for x in state)}

## 12. What platform or feature branches matter?

{bullet(platforms, 'No major platform/feature preprocessor branch was detected.')}

## 13. What can fail, and how should it be debugged?

- Verify material parameters are defined and have the expected type before use.
- Check selected static/dynamic shader combos and the compiled shader variant actually bound at the failing draw.
- Inspect textures, samplers, constant registers, vertex format, transforms, and render target/depth state.
- For baked lighting, compare tool inputs, BSP lumps, lightmap pages, HDR/LDR paths, and runtime decoding.
- For shadows/projected lights, inspect matrices, frusta, depth bias, atlas coordinates, filtering, and pass order.
- Use existing debug ConVars, material overrides, wireframe/fullbright/lightmap views, GPU captures, and assertions close to the state transition.

## 14. What are the main modification risks?

{chr(10).join('- ' + x for x in risk_notes)}

## 15. Which related files should be read next?

{bullet(related, 'Use the include list and manifest dependency index to locate paired helpers, shader sources, and API declarations.')}

## 16. Important source notices, TODOs, or warnings

{bullet(flags, 'No TODO/FIXME/HACK/WARNING/NOTE marker was detected in the file.')}

## Extracted global/static variables

{bullet(syms['globals'])}
"""
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(md, encoding="utf-8")


def copy_file(src_root: Path, rel_s: str, dst_root: Path) -> None:
    src = src_root / rel_s
    dst = dst_root / rel_s
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def write_manifest(root: Path, selected: list[Selection], repo_root: Path) -> None:
    rows = [asdict(s) for s in selected]
    (root / "MANIFEST.json").write_text(json.dumps({
        "repository": "nn-firc/source-sdk-2012",
        "upstream": UPSTREAM,
        "commit": PINNED_COMMIT,
        "selected_count": len(selected),
        "documented_h_cpp_count": sum(Path(s.path).suffix.lower() in DOC_EXTENSIONS for s in selected),
        "files": rows,
    }, indent=2), encoding="utf-8")
    with (root / "MANIFEST.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["path", "kind", "score", "size_bytes", "line_count", "sha256", "reasons"])
        writer.writeheader()
        for s in selected:
            row = asdict(s)
            row["reasons"] = " | ".join(row["reasons"])
            writer.writerow(row)

    by_kind = Counter(s.kind for s in selected)
    ext_counts = Counter(Path(s.path).suffix.lower() or "[no extension]" for s in selected)
    md = [
        "# Lighting and shader extraction manifest",
        "",
        f"- Repository: `nn-firc/source-sdk-2012`",
        f"- Commit: `{PINNED_COMMIT}`",
        f"- Selected files: **{len(selected):,}**",
        f"- Documented `.h`/`.cpp` files: **{sum(Path(s.path).suffix.lower() in DOC_EXTENSIONS for s in selected):,}**",
        "",
        "## Selection categories",
        "",
    ]
    md.extend(f"- {k}: {v:,}" for k, v in sorted(by_kind.items()))
    md += ["", "## Extensions", ""]
    md.extend(f"- `{k}`: {v:,}" for k, v in sorted(ext_counts.items()))
    md += [
        "", "## Scope method", "",
        "1. The exact upstream commit was checked out detached.",
        "2. Every candidate `.h`/`.cpp` file was read in full and hashed.",
        "3. The complete `materialsystem/stdshaders` tree was retained, including shader source, includes, generated shader include blobs, and build helpers.",
        "4. Explicit shader API and offline-lighting trees were retained for C/C++ sources.",
        "5. Remaining C/C++ files were selected using strong path terms or a conservative full-content semantic score requiring rendering integration evidence.",
        "6. Documentation was generated only for selected `.h` and `.cpp` files, as requested.",
        "", "## File list", "",
    ]
    md.extend(f"- `{s.path}` — {s.kind}" for s in selected)
    (root / "MANIFEST.md").write_text("\n".join(md) + "\n", encoding="utf-8")

    scope = f"""# Scope, guarantees, and limitations

## Guarantee

This archive is generated from the exact commit `{PINNED_COMMIT}` of `nn-firc/source-sdk-2012`. Every selected `.h` and `.cpp` was opened and read in full by the extraction script, hashed, copied byte-for-byte, and documented.

## Meaning of “lighting and shaders”

The archive includes:

- the complete `materialsystem/stdshaders` tree (shader C++, headers, shader-language files, includes, generated shader include blobs, and build helpers);
- C/C++ implementation from the shader API/backend trees;
- C/C++ implementation from explicit offline-lighting/radiosity trees;
- lighting/shader files elsewhere in the SDK selected by strong path identity or conservative full-file semantic evidence;
- indirect helpers whose full content demonstrates a rendering-lighting/shader role.

It deliberately does **not** sweep in every generic renderer, texture, model, math, container, platform, or third-party file merely because a lighting/shader file includes it. That would turn the package into most of the SDK and violate the instruction to document only shader/lighting files.

## Documentation method

The per-file Markdown is static-analysis documentation, not a claim of dynamic call-graph completeness. It extracts comments, declarations, functions, includes, macros, feature guards, state/performance indicators, and source notices, then provides focused engineering questions and risks.

## Legal

The upstream `LICENSE` and `thirdpartylegalnotices.txt` are included at the archive root and under `files/` when present. Distribution remains subject to those terms.
"""
    (root / "SCOPE_AND_METHOD.md").write_text(scope, encoding="utf-8")


def build(repo_root: Path, out_root: Path) -> list[Selection]:
    selected: list[Selection] = []
    all_paths = sorted(p for p in repo_root.rglob("*") if p.is_file() and ".git" not in p.parts)
    for p in all_paths:
        rel = p.relative_to(repo_root)
        rel_s = normalized(rel)
        suffix = p.suffix.lower()
        # Full standard shader tree: retain every regular file, but analysis text
        # is decoded only for classification/docs. Elsewhere, consider C++ and
        # shader-language files only.
        is_whole_tree = any(rel_s.lower().startswith(pref) for pref in WHOLE_TREE_PREFIXES)
        if not is_whole_tree and suffix not in CPP_EXTENSIONS and suffix not in SHADER_EXTENSIONS:
            continue
        text, raw = read_text_lossless(p)
        sel = classify(rel, text, raw)
        if sel:
            selected.append(sel)

    selected.sort(key=lambda s: s.path.lower())
    files_root = out_root / "files"
    docs_root = out_root / "documentation"
    files_root.mkdir(parents=True, exist_ok=True)
    docs_root.mkdir(parents=True, exist_ok=True)

    for sel in selected:
        copy_file(repo_root, sel.path, files_root)
        if Path(sel.path).suffix.lower() in DOC_EXTENSIONS:
            make_doc(repo_root, sel, docs_root / f"{sel.path}.md")

    for legal in ("LICENSE", "thirdpartylegalnotices.txt"):
        src = repo_root / legal
        if src.exists():
            shutil.copy2(src, out_root / legal)
            copy_file(repo_root, legal, files_root)

    write_manifest(out_root, selected, repo_root)
    return selected


def zip_root(root: Path, zip_path: Path) -> None:
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as zf:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(root).as_posix())


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--work", default="work")
    parser.add_argument("--output", default="source-sdk-2012-lighting-shaders.zip")
    args = parser.parse_args()
    work = Path(args.work).resolve()
    repo = work / "upstream"
    root = work / "root"
    zip_path = Path(args.output).resolve()
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True)
    clone_pinned(repo)
    selected = build(repo, root)
    zip_root(root, zip_path)
    print(json.dumps({
        "zip": str(zip_path),
        "selected": len(selected),
        "documented": sum(Path(s.path).suffix.lower() in DOC_EXTENSIONS for s in selected),
        "bytes": zip_path.stat().st_size,
        "sha256": hashlib.sha256(zip_path.read_bytes()).hexdigest(),
    }, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
